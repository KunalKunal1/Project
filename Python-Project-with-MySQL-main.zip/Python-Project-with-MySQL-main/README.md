# Python-Project-with-MySQL
Python as frontend and MySQL as backend
